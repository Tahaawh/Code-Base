def sum_two(a, b):
    return a + b

x = sum_two(6, 8)
print(x)
