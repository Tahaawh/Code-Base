def sum_extended(a=0, b=0, c=0, d=0, e=0):
    return a + b + c + d + e

# Testing the function with different numbers of arguments
print(sum_extended(2, 3))         # Output: 5
print(sum_extended(2, 3, 4))      # Output: 9
print(sum_extended(2, 3, 4, 5))   # Output: 14
print(sum_extended(2, 3, 4, 5, 6)) # Output: 20
