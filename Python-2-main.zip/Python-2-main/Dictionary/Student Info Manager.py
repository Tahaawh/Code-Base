info = {"name": "Hassan", "surname": "Rahimi", "id": "1234567890", "average": 16.8}

info["address"] = "Isfahan"
info["average"] = 17.9
del info["id"]

print(info)