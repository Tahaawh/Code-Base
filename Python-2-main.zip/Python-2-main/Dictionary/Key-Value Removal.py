number_dict = {10: "ten", 20: "twenty", 30: "thirty", 40: "forty"}
removed_value = number_dict.pop(40)  
print(number_dict)