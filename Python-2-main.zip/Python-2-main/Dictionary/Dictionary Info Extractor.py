person = {"name": "Mina", "surname": "Zarei", "id": "456789123", "average": 18.2}

print("id" in person)
print(len(person))

keys_list = list(person.keys())
print(keys_list)
print(person.keys())
values_list = list(person.values())
print(values_list)