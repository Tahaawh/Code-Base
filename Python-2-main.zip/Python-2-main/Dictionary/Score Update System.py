student_scores = {'Ali': 85, 'Reza': 92}
new_scores = {'Reza': 95, 'Sara': 88}

student_scores.update(new_scores)
print(student_scores)