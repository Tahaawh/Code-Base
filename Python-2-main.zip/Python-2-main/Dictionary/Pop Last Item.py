data = {1: "a", 2: "b", 3: "c", 4: "d"}

last_item = data.popitem()

print(last_item)  
print(data)