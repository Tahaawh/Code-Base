person = {"name": "Fatemeh", "surname": "Kiani", "id": "9988776655", "average": 19.1}

for key, value in person.items():
    print(key, value)

print(person.items())