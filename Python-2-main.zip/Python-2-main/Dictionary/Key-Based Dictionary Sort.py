unsorted_data = {5: "e", 2: "b", 1: "a", 3: "c"}
sorted_data = dict(sorted(unsorted_data.items()))  
print(sorted_data)