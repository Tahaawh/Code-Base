for i in range(1, 5):
    for j in range(1, 5):
        if i + j == 5:
            print(1, end="")
        else:
            print(0, end="")
    print()
